/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vue;

import DAO.*;
import DAO_Factory.DAO_Factory;
import java.util.ArrayList;
import java.util.Iterator;
import modele.*;

/**
 *
 * @author coline
 */


public class Test {
    /*
    public static void main(String[] args){
        
            //Niveau p1= new Niveau(5, "ING5");
            //DAO<Niveau> p = DAO_Factory.getNiveauDAO();
            
            //if(p.create(p1)){
              //  System.out.println("C'est bon");
            //}
           
           BDD bdd = new BDD(); //ALLER REGARDER DANS LA CLASSE BDD POUR COMPRENDRE
           //CETTE METHODE EXTRAIT TOUTES LES DONNEES DE PHPMYADMIN ET MET AUSSI A JOUR LA BDD LOCALE SUR JAVA
    //CALCULE AUSSI TOUTES LES MOYENNES ET RELIE LES ARRAYLIST  ENTRE EUX
    //C'est en quelque sorte un répertoire
    
    
    
           for(Bulletin B : bdd.getListBulletin()) {     
               System.out.println("BulletinID="+B.get_ID_Bulletin()+"\tMoyenne Genérale Elève="+B.getMoyenneGeneraleEleve()+"\tMoyenne Genérale Classe="+B.getMoyenneGeneraleClasse());
           } //perfect !!
           
    }*/
    
}
