/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vue;

import DAO.DAOEcole;
import java.sql.*;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import modele.Ecole;

/**
 *
 * @author LOL
 */
public class essai {
    private ArrayList<Ecole> listEcole;
    
    public essai(){
        listEcole=new ArrayList<Ecole>();
  }
    
    public void getData(){
        //Faire  DAOEcole e;
        //e.getData(); pour récupérer les données dans un ArrayList
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/gestion_ecole", "root", "");
            Statement stmt = conn.createStatement();
            ResultSet result = stmt.executeQuery("SELECT * FROM ecole");
            while(result.next()){
                Ecole ecole = new Ecole(result.getInt("id_ecole"),result.getString("nom_ecole"),result.getString("adresse_ecole"));
                listEcole.add(ecole); 
                //System.out.println("ecole = "+result.getString("nom_ecole"));
            }
            stmt.close();
            conn.close();
            System.out.println("Ok");
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(DAOEcole.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public ArrayList<Ecole> getList(){
        return listEcole;
    }
    /*
    public static void main(String arg[]){
        
         essai e = new essai();
           e.getData();
           ArrayList<Ecole> ecole = e.getList();
          
               for(Ecole ec : ecole) {
               System.out.println("id = "+ec.get_ID_Ecole()+"\nnom = "+ec.get_Nom_Ecole()+"\nAdresse = "+ec.get_Adresse_Ecole());
               
            }
           
           
    }*/
}
