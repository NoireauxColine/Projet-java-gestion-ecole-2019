/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modele;

/**
 *
 * @author coline
 */
public class Inscription {
        
    //Attributs
    private int id_inscription;
    private int id_classe;
    private int id_personne;
    
    //Constructeur par defaut
    public Inscription(){
        id_inscription=0;
        id_classe=0;
        id_personne=0;
    }
    
    //Constructeur surcharge
    public Inscription(int id_inscription, int id_classe, int id_personne){
        this.id_inscription=id_inscription;
        this.id_classe=id_classe;
        this.id_personne=id_personne;
    }
    
    //getter et setter
    public int get_ID_Inscription(){
        return id_inscription;
    }
    
    public void set_ID_Inscription(int id_inscription){
        this.id_inscription=id_inscription;
    }

    public int get_ID_Classe() {
        return id_classe;
    }

    public void set_ID_Classe(int id_classe) {
        this.id_classe = id_classe;
    }

    public int get_ID_Personne() {
        return id_personne;
    }

    public void set_ID_Personne(int id_personne) {
        this.id_personne = id_personne;
    }
    
}
