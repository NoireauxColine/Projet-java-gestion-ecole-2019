/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modele;

/**
 *
 * @author coline
 */
public class Classe {
        
    //Attributs
    private int id_classe;
    private String nom_classe;
    private int id_ecole;
    private int id_niveau;
    private int id_annee_scolaire;
    
    //Constructeur par defaut
    public Classe(){
        id_classe=0;
        nom_classe=null;
        id_ecole=0;
        id_niveau=0;
        id_annee_scolaire=0;
    }
    
    //Constructeur surcharge
    public Classe(int id_classe, String nom_classe, int id_ecole, int id_niveau, int id_annee_scolaire){
        this.id_classe=id_classe;
        this.nom_classe=nom_classe;
        this.id_ecole=id_ecole;
        this.id_niveau=id_niveau;
        this.id_annee_scolaire=id_annee_scolaire;
    }
    
    //getter et setter
    public int get_ID_Classe(){
        return id_classe;
    }
    
    public void set_ID_Classe(int id_classe){
        this.id_classe=id_classe;
    }
    
    public String get_Nom_Classe(){
        return nom_classe;
    }
    
    public void set_Nom_Classe(String nom_classe){
        this.nom_classe=nom_classe;
    }

    public int getId_ecole() {
        return id_ecole;
    }

    public void setId_ecole(int id_ecole) {
        this.id_ecole = id_ecole;
    }

    public int getId_niveau() {
        return id_niveau;
    }

    public void setId_niveau(int id_niveau) {
        this.id_niveau = id_niveau;
    }

    public int getId_annee_scolaire() {
        return id_annee_scolaire;
    }

    public void setId_annee_scolaire(int id_annee_scolaire) {
        this.id_annee_scolaire = id_annee_scolaire;
    }
    
}
