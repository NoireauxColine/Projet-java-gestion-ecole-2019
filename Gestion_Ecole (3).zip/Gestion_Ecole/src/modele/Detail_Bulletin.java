/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modele;

/**
 *
 * @author coline
 */
public class Detail_Bulletin {
    
    //Attributs
    private int id_detail_bulletin;
    private String appreciation_detail;
    private int id_bulletin;
    private int id_enseignement;
    
    //Constructeur par defaut
    public Detail_Bulletin(){
        id_detail_bulletin=0;
        appreciation_detail=null;
        id_bulletin=0;
        id_enseignement=0;
    }
    
    //Constructeur surcharge
    public Detail_Bulletin(int id_detail_bulletin, int id_bulletin, int id_enseignement, String appreciation_detail){
        this.id_detail_bulletin=id_detail_bulletin;
        this.appreciation_detail=appreciation_detail;
        this.id_bulletin=id_bulletin;
        this.id_enseignement=id_enseignement;
    }
    
    //getter et setter
    public int get_ID_Detail(){
        return id_detail_bulletin;
    }
    
    public void set_ID_Detail(int id_detail_bulletin){
        this.id_detail_bulletin=id_detail_bulletin;
    }
    
    public String get_Appreciation_Detail(){
        return appreciation_detail;
    }
    
    public void set_Appreciation_Detail(String appreciation_detail){
        this.appreciation_detail=appreciation_detail;
    }

    public int getId_bulletin() {
        return id_bulletin;
    }

    public void setId_bulletin(int id_bulletin) {
        this.id_bulletin = id_bulletin;
    }

    public int getId_enseignement() {
        return id_enseignement;
    }

    public void setId_enseignement(int id_enseignement) {
        this.id_enseignement = id_enseignement;
    }
    
}
