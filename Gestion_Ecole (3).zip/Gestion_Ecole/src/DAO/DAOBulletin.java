/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.logging.Level;
import java.util.logging.Logger;
import modele.Bulletin;

/**
 *
 * @author coline
 */
public class DAOBulletin extends DAO<Bulletin> {

    public DAOBulletin(Connection conn) {
        super(conn);
    }

    @Override
    public boolean create(Bulletin obj) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        
        try {
            // prefer prepareStatement as statement to avoid SQL injection
            PreparedStatement statement = this.connect.prepareStatement(
                    "INSERT INTO bulletin(id_bulletin,id_trimestre,id_inscription,appreciation_bulletin,moyenne_bulletin) VALUES(?,?,?,?,?)"
            );
            //insert param to change the ? into data
            statement.setObject(1, obj.get_ID_Bulletin(), Types.INTEGER);
            statement.setObject(2, obj.getId_trimestre(), Types.INTEGER);
            statement.setObject(3, obj.getId_inscription(), Types.INTEGER);
            statement.setObject(4, obj.get_Appreciation_Bulletin(), Types.VARCHAR);
            statement.setObject(5, obj.get_Moyenne(), Types.DOUBLE);
            statement.executeUpdate(); //execute update for change in DB and executeQuery for select

        } catch (SQLException ex) {
            Logger.getLogger(DAOPersonne.class.getName()).log(Level.SEVERE, null, ex);
        }
        return true;
    }

    @Override
    public boolean delete(Bulletin obj) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        
        try {
            // prefer prepareStatement as statement to avoid SQL injection
            PreparedStatement statement = this.connect.prepareStatement(
                    "DELETE FROM bulletin WHERE id_bulletin=?"
            );
            //insert param to change the ? into data
            statement.setObject(1, obj.get_ID_Bulletin(), Types.INTEGER);
            statement.executeUpdate(); //execute update for change in DB and executeQuery for select

        } catch (SQLException ex) {
            Logger.getLogger(DAOPersonne.class.getName()).log(Level.SEVERE, null, ex);
        }
        return true;
    }

    @Override
    public boolean update(Bulletin obj) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        
            try {
            // prefer prepareStatement as statement to avoid SQL injection
            PreparedStatement statement = this.connect.prepareStatement(
                    "UPDATE bulletin SET id_trimestre=?,id_inscription=?,appreciation_bulletin=?, moyenne_bulletin=?, WHERE id_bulletin=?"
            );
            //insert param to change the ? into data
            
            statement.setObject(1, obj.getId_trimestre(), Types.INTEGER);
            statement.setObject(2, obj.getId_inscription(), Types.INTEGER);            
            statement.setObject(3, obj.get_Appreciation_Bulletin(), Types.VARCHAR);
            statement.setObject(4, obj.get_Moyenne(), Types.DOUBLE);
            statement.setObject(5, obj.get_ID_Bulletin(), Types.INTEGER);
            
            statement.executeUpdate(); //execute update for change in DB and executeQuery for select

        } catch (SQLException ex) {
            Logger.getLogger(DAOPersonne.class.getName()).log(Level.SEVERE, null, ex);
        }
        return true;
    }

    @Override
    public Bulletin find(int id_bulletin) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        
            Bulletin bulletin = new Bulletin();      
      
    try {
      ResultSet result = this.connect.createStatement(
        ResultSet.TYPE_SCROLL_INSENSITIVE,
        ResultSet.CONCUR_READ_ONLY).executeQuery("SELECT * FROM bulletin WHERE id_bulletin = " + id_bulletin);
      if(result.first())
        bulletin = new Bulletin(
          id_bulletin,          
          result.getInt("id_trimestre"),
          result.getInt("id_inscription"),
          result.getString("appreciaton_bulletin"),
          result.getFloat("moyenne_bulletin")
        );         
    } catch (SQLException e) {
      e.printStackTrace();
    }
    return bulletin;
    }
    
}
