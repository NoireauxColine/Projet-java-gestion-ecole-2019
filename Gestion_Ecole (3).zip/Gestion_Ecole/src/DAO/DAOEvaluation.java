/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.logging.Level;
import java.util.logging.Logger;
import modele.Evaluation;

/**
 *
 * @author coline
 */
public class DAOEvaluation extends DAO<Evaluation>{

    public DAOEvaluation(Connection conn) {
        super(conn);
    }

    @Override
    public boolean create(Evaluation obj) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        
        try {
            // prefer prepareStatement as statement to avoid SQL injection
            PreparedStatement statement = this.connect.prepareStatement(
                    "INSERT INTO evaluation(id_evaluation,id_detail_bulletin,note_evaluation,appreciation_evaluation) VALUES(?,?,?,?)"
            );
            //insert param to change the ? into data
            statement.setObject(1, obj.get_ID_Evaluation(), Types.INTEGER);
            statement.setObject(2, obj.getId_detail_bulletin(), Types.INTEGER);
            statement.setObject(3, obj.get_Note_Evaluation(), Types.DOUBLE);
            statement.setObject(4, obj.get_Appreciation_Evaluation(), Types.VARCHAR);

            statement.executeUpdate(); //execute update for change in DB and executeQuery for select

        } catch (SQLException ex) {
            Logger.getLogger(DAOPersonne.class.getName()).log(Level.SEVERE, null, ex);
        }
        return true;
    }

    @Override
    public boolean delete(Evaluation obj) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        
         try {
            // prefer prepareStatement as statement to avoid SQL injection
            PreparedStatement statement = this.connect.prepareStatement(
                    "DELETE FROM evaluation WHERE id_evaluation=?"
            );
            //insert param to change the ? into data
            statement.setObject(1, obj.get_ID_Evaluation(), Types.INTEGER);
            statement.executeUpdate(); //execute update for change in DB and executeQuery for select

        } catch (SQLException ex) {
            Logger.getLogger(DAOPersonne.class.getName()).log(Level.SEVERE, null, ex);
        }
        return true;
    }

    @Override
    public boolean update(Evaluation obj) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        
        try {
            // prefer prepareStatement as statement to avoid SQL injection
            PreparedStatement statement = this.connect.prepareStatement(
                    "UPDATE evaluation SET id_detail_bulletin=?, note_evaluation=?, appreciation_evaluation=?, WHERE id_evaluation=?"
            );
            //insert param to change the ? into data
            statement.setObject(1, obj.getId_detail_bulletin(), Types.INTEGER);
            statement.setObject(2, obj.get_Note_Evaluation(), Types.DOUBLE);
            statement.setObject(3, obj.get_Appreciation_Evaluation(), Types.VARCHAR);
            statement.setObject(4, obj.get_ID_Evaluation(), Types.INTEGER);
            statement.executeUpdate(); //execute update for change in DB and executeQuery for select

        } catch (SQLException ex) {
            Logger.getLogger(DAOPersonne.class.getName()).log(Level.SEVERE, null, ex);
        }
        return true;
    }

    @Override
    public Evaluation find(int id_evaluation) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        
            Evaluation evaluation = new Evaluation();      
      
    try {
      ResultSet result = this.connect.createStatement(
        ResultSet.TYPE_SCROLL_INSENSITIVE,
        ResultSet.CONCUR_READ_ONLY).executeQuery("SELECT * FROM evaluation WHERE id_evaluation = " + id_evaluation);
      if(result.first())
        evaluation = new Evaluation(
          id_evaluation,
          result.getInt("id_detail_bulletin"),
          result.getFloat("note_evaluation"),
          result.getString("appreciation_evalution")
          
        );         
    } catch (SQLException e) {
      e.printStackTrace();
    }
    return evaluation;
    }
    
}
