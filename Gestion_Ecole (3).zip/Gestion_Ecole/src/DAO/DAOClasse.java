/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.logging.Level;
import java.util.logging.Logger;
import modele.Classe;

/**
 *
 * @author coline
 */
public class DAOClasse extends DAO<Classe> {

    public DAOClasse(Connection conn) {
        super(conn);
    }

    @Override
    public boolean create(Classe obj) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        
        try {
            // prefer prepareStatement as statement to avoid SQL injection
            PreparedStatement statement = this.connect.prepareStatement(
                    "INSERT INTO classe(id_classe,nom_classe,id_ecole,id_niveau,id_annee_scolaire) VALUES(?,?,?,?,?)"
            );
            //insert param to change the ? into data
            statement.setObject(1, obj.get_ID_Classe(), Types.INTEGER);
            statement.setObject(2, obj.get_Nom_Classe(), Types.VARCHAR);
            statement.setObject(3, obj.getId_ecole(), Types.INTEGER);
            statement.setObject(4, obj.getId_niveau(), Types.INTEGER);
            statement.setObject(5, obj.getId_annee_scolaire(), Types.INTEGER);
            statement.executeUpdate(); //execute update for change in DB and executeQuery for select

        } catch (SQLException ex) {
            Logger.getLogger(DAOPersonne.class.getName()).log(Level.SEVERE, null, ex);
        }
        return true;
    }

    @Override
    public boolean delete(Classe obj) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        
        try {
            // prefer prepareStatement as statement to avoid SQL injection
            PreparedStatement statement = this.connect.prepareStatement(
                    "DELETE FROM classe WHERE id_classe=?"
            );
            //insert param to change the ? into data
            statement.setObject(1, obj.get_ID_Classe(), Types.INTEGER);
            statement.executeUpdate(); //execute update for change in DB and executeQuery for select

        } catch (SQLException ex) {
            Logger.getLogger(DAOPersonne.class.getName()).log(Level.SEVERE, null, ex);
        }
        return true;
    }

    @Override
    public boolean update(Classe obj) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        
        try {
            // prefer prepareStatement as statement to avoid SQL injection
            PreparedStatement statement = this.connect.prepareStatement(
                    "UPDATE classe SET nom_classe=?, id_ecole=?,id_niveau=?,id_annee_scolaire=? WHERE id_classe=?"
            );
            //insert param to change the ? into data
            
            statement.setObject(1, obj.get_Nom_Classe(), Types.VARCHAR);
            statement.setObject(2, obj.getId_ecole(), Types.INTEGER);
            statement.setObject(3, obj.getId_niveau(), Types.INTEGER);
            statement.setObject(4, obj.getId_annee_scolaire(), Types.INTEGER);
            statement.setObject(5, obj.get_ID_Classe(), Types.INTEGER);
            statement.executeUpdate(); //execute update for change in DB and executeQuery for select

        } catch (SQLException ex) {
            Logger.getLogger(DAOPersonne.class.getName()).log(Level.SEVERE, null, ex);
        }
        return true;
    }

    @Override
    public Classe find(int id_classe) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        
            Classe classe = new Classe();      
      
    try {
      ResultSet result = this.connect.createStatement(
        ResultSet.TYPE_SCROLL_INSENSITIVE,
        ResultSet.CONCUR_READ_ONLY).executeQuery("SELECT * FROM classe WHERE id_classe = " + id_classe);
      if(result.first())
        classe = new Classe(
          id_classe,
          result.getString("nom_classe"),
          result.getInt("id_ecole"),
          result.getInt("id_niveau"),
          result.getInt("id_annee_scolaire")
          );         
    } catch (SQLException e) {
      e.printStackTrace();
    }
    return classe;
    }
    
}
