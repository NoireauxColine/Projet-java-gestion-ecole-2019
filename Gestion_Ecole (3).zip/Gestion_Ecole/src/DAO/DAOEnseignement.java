/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.logging.Level;
import java.util.logging.Logger;
import modele.Enseignement;

/**
 *
 * @author coline
 */
public class DAOEnseignement extends DAO<Enseignement>{

    public DAOEnseignement(Connection conn) {
        super(conn);
    }

    @Override
    public boolean create(Enseignement obj) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        
         try {
            // prefer prepareStatement as statement to avoid SQL injection
            PreparedStatement statement = this.connect.prepareStatement(
                    "INSERT INTO enseignement(id_enseignement,id_classe,id_discipline,id_personne) VALUES(?,?,?,?)"
            );
            //insert param to change the ? into data
            statement.setObject(1, obj.get_ID_Enseignement(), Types.INTEGER);
            statement.setObject(2, obj.getId_classe(), Types.INTEGER);
            statement.setObject(3, obj.getId_discipline(), Types.INTEGER);
            statement.setObject(4, obj.getId_personne(), Types.INTEGER);
            

            statement.executeUpdate(); //execute update for change in DB and executeQuery for select

        } catch (SQLException ex) {
            Logger.getLogger(DAOPersonne.class.getName()).log(Level.SEVERE, null, ex);
        }
        return true;
    }

    @Override
    public boolean delete(Enseignement obj) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        
        try {
            // prefer prepareStatement as statement to avoid SQL injection
            PreparedStatement statement = this.connect.prepareStatement(
                    "DELETE FROM enseignement WHERE id_enseignement=?"
            );
            //insert param to change the ? into data
            statement.setObject(1, obj.get_ID_Enseignement(), Types.INTEGER);
            statement.executeUpdate(); //execute update for change in DB and executeQuery for select

        } catch (SQLException ex) {
            Logger.getLogger(DAOPersonne.class.getName()).log(Level.SEVERE, null, ex);
        }
        return true;
    }

    @Override
    public boolean update(Enseignement obj) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        
        try {
            // prefer prepareStatement as statement to avoid SQL injection
            PreparedStatement statement = this.connect.prepareStatement(
                    "UPDATE enseignement SET id_classe=?, id_discipline=?, id_personne=?, WHERE id_enseignement=?"
            );
            //insert param to change the ? into data
            statement.setObject(1, obj.getId_classe(), Types.VARCHAR);
            statement.setObject(2, obj.getId_discipline(), Types.VARCHAR);
            statement.setObject(3, obj.getId_personne(), Types.INTEGER);
            statement.setObject(4, obj.get_ID_Enseignement(), Types.INTEGER);
            statement.executeUpdate(); //execute update for change in DB and executeQuery for select

        } catch (SQLException ex) {
            Logger.getLogger(DAOPersonne.class.getName()).log(Level.SEVERE, null, ex);
        }
        return true;
    }

    @Override
    public Enseignement find(int id_enseignement) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        
            Enseignement enseignement = new Enseignement();      
      
    try {
      ResultSet result = this.connect.createStatement(
        ResultSet.TYPE_SCROLL_INSENSITIVE,
        ResultSet.CONCUR_READ_ONLY).executeQuery("SELECT * FROM enseignement WHERE id_enseignement = " + id_enseignement);
      if(result.first())
        enseignement = new Enseignement(
          id_enseignement,
          result.getInt("id_classe"),
          result.getInt("id_discipline"),
          result.getInt("id_personne")
         );         
    } catch (SQLException e) {
      e.printStackTrace();
    }
    return enseignement;
    }
    
}
