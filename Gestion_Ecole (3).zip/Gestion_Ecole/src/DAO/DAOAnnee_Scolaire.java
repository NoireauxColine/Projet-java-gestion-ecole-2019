/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.logging.Level;
import java.util.logging.Logger;
import modele.Annee_Scolaire;

/**
 *
 * @author coline
 */
public class DAOAnnee_Scolaire extends DAO<Annee_Scolaire> {

    public DAOAnnee_Scolaire(Connection conn) {
        super(conn);
    }

    @Override
    public boolean create(Annee_Scolaire obj) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        
          try {
            // prefer prepareStatement as statement to avoid SQL injection
            PreparedStatement statement = this.connect.prepareStatement(
                    "INSERT INTO annee_scolaire(id_annee_scolaire) VALUES(?)"
            );
            //insert param to change the ? into data
            statement.setObject(1, obj.get_ID_Annee(), Types.INTEGER);
            statement.executeUpdate(); //execute update for change in DB and executeQuery for select

        } catch (SQLException ex) {
            Logger.getLogger(DAOPersonne.class.getName()).log(Level.SEVERE, null, ex);
        }
        return true;
        
        
    }

    @Override
    public boolean delete(Annee_Scolaire obj) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        
         try {
            // prefer prepareStatement as statement to avoid SQL injection
            PreparedStatement statement = this.connect.prepareStatement(
                    "DELETE FROM annee_scolaire WHERE id_annee_scolaire=?"
            );
            //insert param to change the ? into data
            statement.setObject(1, obj.get_ID_Annee(), Types.INTEGER);
            statement.executeUpdate(); //execute update for change in DB and executeQuery for select

        } catch (SQLException ex) {
            Logger.getLogger(DAOPersonne.class.getName()).log(Level.SEVERE, null, ex);
        }
        return true;
    }

    @Override
    public boolean update(Annee_Scolaire obj) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Annee_Scolaire find(int id_annee_scolaire) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        
            Annee_Scolaire annee = new Annee_Scolaire();      
      
    try {
      ResultSet result = this.connect.createStatement(
        ResultSet.TYPE_SCROLL_INSENSITIVE,
        ResultSet.CONCUR_READ_ONLY).executeQuery("SELECT * FROM annee_scolaire WHERE id_annee_scolaire = " + id_annee_scolaire);
      if(result.first())
        annee = new Annee_Scolaire(
          id_annee_scolaire
          );         
    } catch (SQLException e) {
      e.printStackTrace();
    }
    return annee;
    }
    
}
