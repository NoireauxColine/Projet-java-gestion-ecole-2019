/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.logging.Level;
import java.util.logging.Logger;
import modele.Discipline;

/**
 *
 * @author coline
 */
public class DAODiscipline extends DAO<Discipline>{

    public DAODiscipline(Connection conn) {
        super(conn);
    }

    @Override
    public boolean create(Discipline obj) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        
         try {
            // prefer prepareStatement as statement to avoid SQL injection
            PreparedStatement statement = this.connect.prepareStatement(
                    "INSERT INTO discipline(id_discipline,nom_discipline) VALUES(?,?)"
            );
            //insert param to change the ? into data
            statement.setObject(1, obj.get_ID_Discipline(), Types.INTEGER);
            statement.setObject(2, obj.get_Nom_Discipline(), Types.VARCHAR);

            statement.executeUpdate(); //execute update for change in DB and executeQuery for select

        } catch (SQLException ex) {
            Logger.getLogger(DAOPersonne.class.getName()).log(Level.SEVERE, null, ex);
        }
        return true;
    }

    @Override
    public boolean delete(Discipline obj) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        
         try {
            // prefer prepareStatement as statement to avoid SQL injection
            PreparedStatement statement = this.connect.prepareStatement(
                    "DELETE FROM discipline WHERE id_discipline=?"
            );
            //insert param to change the ? into data
            statement.setObject(1, obj.get_ID_Discipline(), Types.INTEGER);
            statement.executeUpdate(); //execute update for change in DB and executeQuery for select

        } catch (SQLException ex) {
            Logger.getLogger(DAOPersonne.class.getName()).log(Level.SEVERE, null, ex);
        }
        return true;
    }

    @Override
    public boolean update(Discipline obj) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        
        try {
            // prefer prepareStatement as statement to avoid SQL injection
            PreparedStatement statement = this.connect.prepareStatement(
                    "UPDATE discipline SET nom_discipline=?, WHERE id_discipline=?"
            );
            //insert param to change the ? into data
            statement.setObject(1, obj.get_Nom_Discipline(), Types.VARCHAR);
            statement.setObject(2, obj.get_ID_Discipline(), Types.INTEGER);
            statement.executeUpdate(); //execute update for change in DB and executeQuery for select

        } catch (SQLException ex) {
            Logger.getLogger(DAOPersonne.class.getName()).log(Level.SEVERE, null, ex);
        }
        return true;
    }

    @Override
    public Discipline find(int id_discipline) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        
            Discipline discipline = new Discipline();      
      
    try {
      ResultSet result = this.connect.createStatement(
        ResultSet.TYPE_SCROLL_INSENSITIVE,
        ResultSet.CONCUR_READ_ONLY).executeQuery("SELECT * FROM discipline WHERE id_discipline = " + id_discipline);
      if(result.first())
        discipline = new Discipline(
          id_discipline,
          result.getString("nom_discipline")
          );         
    } catch (SQLException e) {
      e.printStackTrace();
    }
    return discipline;
    }
    
}
