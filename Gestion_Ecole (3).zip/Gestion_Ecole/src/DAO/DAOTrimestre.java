/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.logging.Level;
import java.util.logging.Logger;
import modele.Trimestre;

/**
 *
 * @author coline
 */
public class DAOTrimestre extends DAO<Trimestre>{

    public DAOTrimestre(Connection conn) {
        super(conn);
    }

    @Override
    public boolean create(Trimestre obj) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        
        try {
            // prefer prepareStatement as statement to avoid SQL injection
            PreparedStatement statement = this.connect.prepareStatement(
                    "INSERT INTO trimestre(id_trimestre,numero_trimestre,debut_trimestre, fin_trimestre,id_annee_scolaire) VALUES(?,?,?,?,?)"
            );
            //insert param to change the ? into data
            statement.setObject(1, obj.get_ID_Trimestre(), Types.INTEGER);
            statement.setObject(2, obj.get_Numero_Trimestre(), Types.INTEGER);
            statement.setObject(3, obj.get_Date_Debut(), Types.DATE);
            statement.setObject(4, obj.get_Date_Fin(), Types.DATE);
            statement.setObject(5, obj.getId_annee_scolaire(), Types.INTEGER);

            statement.executeUpdate(); //execute update for change in DB and executeQuery for select

        } catch (SQLException ex) {
            Logger.getLogger(DAOPersonne.class.getName()).log(Level.SEVERE, null, ex);
        }
        return true;
    }

    @Override
    public boolean delete(Trimestre obj) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        
         try {
            // prefer prepareStatement as statement to avoid SQL injection
            PreparedStatement statement = this.connect.prepareStatement(
                    "DELETE FROM trimestre WHERE id_trimestre=?"
            );
            //insert param to change the ? into data
            statement.setObject(1, obj.get_ID_Trimestre(), Types.INTEGER);
            statement.executeUpdate(); //execute update for change in DB and executeQuery for select

        } catch (SQLException ex) {
            Logger.getLogger(DAOPersonne.class.getName()).log(Level.SEVERE, null, ex);
        }
        return true;
    }

    @Override
    public boolean update(Trimestre obj) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        
         try {
            // prefer prepareStatement as statement to avoid SQL injection
            PreparedStatement statement = this.connect.prepareStatement(
                    "UPDATE trimestre SET numero_trimestre=?, debut_trimestre=?, fin_trimestre=?, id_annee_scolaire=?,  WHERE id_trimestre=?"
            );
            //insert param to change the ? into data
            statement.setObject(1, obj.get_Numero_Trimestre(), Types.INTEGER);
            statement.setObject(2, obj.get_Date_Debut(), Types.DATE);
            statement.setObject(3, obj.get_Date_Fin(), Types.DATE);
            statement.setObject(4, obj.getId_annee_scolaire(), Types.INTEGER);
            statement.setObject(5, obj.get_ID_Trimestre(), Types.INTEGER);
            statement.executeUpdate(); //execute update for change in DB and executeQuery for select

        } catch (SQLException ex) {
            Logger.getLogger(DAOPersonne.class.getName()).log(Level.SEVERE, null, ex);
        }
        return true;
    }

    @Override
    public Trimestre find(int id_trimestre) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        
                Trimestre trimestre = new Trimestre();      
      
    try {
      ResultSet result = this.connect.createStatement(
        ResultSet.TYPE_SCROLL_INSENSITIVE,
        ResultSet.CONCUR_READ_ONLY).executeQuery("SELECT * FROM trimestre WHERE id_trimestre = " + id_trimestre);
      if(result.first())
        trimestre = new Trimestre(
          id_trimestre,
          result.getInt("numero_trimestre"),
          result.getDate("debut_trimestre"),
          result.getDate("fin_trimestre"),
          result.getInt("id_annee_scolaire")
          );         
    } catch (SQLException e) {
      e.printStackTrace();
    }
    return trimestre;
    }
    
}
    

