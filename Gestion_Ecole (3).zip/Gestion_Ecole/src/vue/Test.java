/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vue;

import DAO.DAO;
import DAO_Factory.DAO_Factory;
import modele.Annee_Scolaire;
import modele.Bulletin;
import modele.Classe;
import modele.Detail_Bulletin;
import modele.Discipline;
import modele.Ecole;
import modele.Enseignement;
import modele.Evaluation;
import modele.Inscription;
import modele.Niveau;
import modele.Personne;

/**
 *
 * @author coline
 */


public class Test {
    
    public static void main(String[] args){
        
            Niveau p1= new Niveau(5, "ING5");
            DAO<Niveau> p = DAO_Factory.getNiveauDAO();
            
            if(p.create(p1)){
                System.out.println("C'est bon");
            }
            
            
      

    }
    
}
