/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vue;

import DAO.*;
import DAO_Factory.DAO_Factory;
import java.util.ArrayList;
import java.util.Iterator;
import modele.*;

/**
 *
 * @author coline
 */


public class Test {
    
    public static void main(String[] args){
        
            Personne p1= new Personne(19, "coco", "coco", "Eleve", "coco.coco", "1234");
            DAO<Personne> p = DAO_Factory.getPersonneDAO();
            
            if(p.create(p1)){
                System.out.println("C'est bon");
            }
           
           /*
           //TEST DE RECUPERATION DE LA BDD ET AFFICHAGE DES DONNEES
           
           System.out.println("Table Ecole :");
           DAOEcole e = new DAOEcole();
           e.setData();
           ArrayList<Ecole> ecole = e.getList();
           for(Ecole ec : ecole) {
               System.out.println("id = "+ec.get_ID_Ecole()+"\tnom = "+ec.get_Nom_Ecole()+"\tAdresse = "+ec.get_Adresse_Ecole()); 
           }
           
           
           System.out.println("");
           System.out.println("Table Année_Scolaire :");
           DAOAnnee_Scolaire a = new DAOAnnee_Scolaire();
           a.setData();
           ArrayList<Annee_Scolaire> annee = a.getList();
           for(Annee_Scolaire an : annee) {
               System.out.println("annee = "+an.get_ID_Annee()); 
           }
           
           
           System.out.println("");
           System.out.println("Table Personne :");
           DAOPersonne p = new DAOPersonne();
           p.setData();
           ArrayList<Personne> personne = p.getList();
           for(Personne pers : personne) {
               System.out.println("id = "+pers.get_ID_Personne()+"\tnom = "+pers.get_Nom_Personne()+"\tPrénom = "+pers.get_Prenom_Personne()+"\tType = "+pers.get_Type_Personne()); 
           }
           
           
           System.out.println("");
           System.out.println("Table Niveau :");
           DAONiveau n = new DAONiveau();
           n.setData();
           ArrayList<Niveau> niveau = n.getList();
           for(Niveau niv : niveau) {
               System.out.println("id = "+niv.get_ID_Niveau()+"\tNiveau = "+niv.get_Nom_Niveau()); 
           }
           
           
           System.out.println("");
           System.out.println("Table Discipline :");
           DAODiscipline d = new DAODiscipline();
           d.setData();
           ArrayList<Discipline> discipline = d.getList();
           for(Discipline dis : discipline) {
               System.out.println("id = "+dis.get_ID_Discipline()+"\tNiveau = "+dis.get_Nom_Discipline()); 
           }
           
           
           System.out.println("");
           System.out.println("Table Enseignement :");
           DAOEnseignement ens = new DAOEnseignement();
           ens.setData();
           ArrayList<Enseignement> enseignement = ens.getList();
           for(Enseignement prof : enseignement) {
               System.out.println("id = "+prof.get_ID_Enseignement()+"\tclasseID = "+prof.get_ID_Classe()+"\tDisciplineID = "+prof.get_ID_Discipline()+"\tPersonneID = "+prof.get_ID_Personne()); 
           }
           
           System.out.println("");
           System.out.println("Table Classe :");
           DAOClasse c = new DAOClasse();
           c.setData();
           ArrayList<Classe> classe = c.getList();
           for(Classe C : classe) {
               System.out.println("ClasseID = "+C.get_ID_Classe()+"\tNom Classe = "+C.get_Nom_Classe()+"\tEcoleID = "+C.get_ID_Ecole()+"\tNiveauID = "+C.get_ID_Niveau()+"\tAnnee="+C.get_ID_Annee_Scolaire()); 
           }
           
           
           System.out.println("");
           System.out.println("Table Inscription :");
           DAOInscription i = new DAOInscription();
           i.setData();
           ArrayList<Inscription> inscription = i.getList();
           for(Inscription I : inscription) {
               System.out.println("InscriptionID = "+I.get_ID_Inscription()+"\tClasseID = "+I.get_ID_Classe()+"\tPersonneID = "+I.get_ID_Personne()); 
           }
           
           System.out.println("");
           System.out.println("Table Trimestre :");
           DAOTrimestre t = new DAOTrimestre();
           t.setData();
           ArrayList<Trimestre> trimestre = t.getList();
           for(Trimestre I : trimestre) {
               System.out.println("TrimestreID = "+I.get_ID_Trimestre()+"\tTrimestre n°"+I.get_Numero_Trimestre()+"\tDebut = "+I.get_Date_Debut()+"\tFin = "+I.get_Date_Fin()+"\tAnnée = "+I.get_ID_Annee_Scolaire()); 
           }
           
           
           System.out.println("");
           System.out.println("Table Bulletin Global :");
           DAOBulletin b = new DAOBulletin();
           b.setData();
           ArrayList<Bulletin> bulletin_global = b.getList();
           for(Bulletin B : bulletin_global) {
               System.out.println("Bulletin_Global_ID = "+B.get_ID_Bulletin()+"\tTrimestre ID = "+B.get_ID_Trimestre()+"\tInscriptionID = "+B.get_ID_Inscription()+"\tApréciation = "+B.get_Appreciation_Bulletin()); 
           }
           
           
           System.out.println("");
           System.out.println("Table Bulletin Detail :");
           DAODetail_Bulletin db = new DAODetail_Bulletin();
           db.setData();
           ArrayList<Detail_Bulletin> matiere = db.getList();
           for(Detail_Bulletin B : matiere) {
               System.out.println("Bulletin_Global_ID = "+B.get_ID_Bulletin()+"\tBulletinID = "+B.get_ID_Bulletin()+"\tEnseignementID = "+B.get_ID_Enseignement()+"\tAppréciation = "+B.get_Appreciation_Detail()); 
           }
           
           
            System.out.println("");
           System.out.println("Table Evaluation :");
           DAOEvaluation eval = new DAOEvaluation();
           eval.setData();
           ArrayList<Evaluation> DS = eval.getList();
           for(Evaluation B : DS) {
               System.out.println("Evaluation_ID = "+B.get_ID_Evaluation()+"\tDetail_BulletinID = "+B.get_ID_Detail_Bulletin()+"\tNoteID = "+B.get_Note_Evaluation()+"\tAppréciation = "+B.get_Appreciation_Evaluation()); 
           }
           
           
*/
    }
    
}
