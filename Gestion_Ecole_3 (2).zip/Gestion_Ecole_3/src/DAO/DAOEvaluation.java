/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import java.sql.*;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import modele.Evaluation;

/**
 *
 * @author coline & loic
 */
public class DAOEvaluation extends DAO<Evaluation>{

    private ArrayList<Evaluation> listEvaluation;
    
    public DAOEvaluation(){
        listEvaluation=new ArrayList<Evaluation>();
    }
    
    
    public DAOEvaluation(Connection conn) {
        super(conn);
    }
    
    
    @Override
    public void setData(){
        
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/gestion_ecole", "root", "");
            Statement stmt = conn.createStatement();
            ResultSet result = stmt.executeQuery("SELECT * FROM evaluation");
            while(result.next()){
                
                Evaluation DS = new Evaluation(result.getInt("id_evaluation"),result.getInt("id_detail_bulletin"),result.getInt("note_evaluation"),result.getString("appreciation_evaluation"));
                listEvaluation.add(DS);
            }
            stmt.close();
            conn.close();
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(DAOEcole.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public ArrayList<Evaluation> getList(){
        return listEvaluation;
    }

    @Override
    public boolean create(Evaluation obj) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        
        try {
            // prefer prepareStatement as statement to avoid SQL injection
            PreparedStatement statement = this.connect.prepareStatement(
                    "INSERT INTO evaluation(id_evaluation,id_detail_bulletin,note_evaluation,appreciation_evaluation) VALUES(?,?,?,?)"
            );
            //insert param to change the ? into data
            statement.setObject(1, obj.get_ID_Evaluation(), Types.INTEGER);
            statement.setObject(2, obj.get_ID_Detail_Bulletin(), Types.INTEGER);
            statement.setObject(3, obj.get_Note_Evaluation(), Types.DOUBLE);
            statement.setObject(4, obj.get_Appreciation_Evaluation(), Types.VARCHAR);

            statement.executeUpdate(); //execute update for change in DB and executeQuery for select

        } catch (SQLException ex) {
            Logger.getLogger(DAOPersonne.class.getName()).log(Level.SEVERE, null, ex);
        }
        return true;
    }

    @Override
    public boolean delete(Evaluation obj) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        
         try {
            // prefer prepareStatement as statement to avoid SQL injection
            PreparedStatement statement = this.connect.prepareStatement(
                    "DELETE FROM evaluation WHERE id_evaluation=?"
            );
            //insert param to change the ? into data
            statement.setObject(1, obj.get_ID_Evaluation(), Types.INTEGER);
            statement.executeUpdate(); //execute update for change in DB and executeQuery for select

        } catch (SQLException ex) {
            Logger.getLogger(DAOPersonne.class.getName()).log(Level.SEVERE, null, ex);
        }
        return true;
    }

    @Override
    public boolean update(Evaluation obj) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        
        try {
            // prefer prepareStatement as statement to avoid SQL injection
            PreparedStatement statement = this.connect.prepareStatement(
                    "UPDATE evaluation SET id_detail_bulletin=?, note_evaluation=?, appreciation_evaluation=?, WHERE id_evaluation=?"
            );
            //insert param to change the ? into data
            statement.setObject(1, obj.get_ID_Detail_Bulletin(), Types.INTEGER);
            statement.setObject(2, obj.get_Note_Evaluation(), Types.DOUBLE);
            statement.setObject(3, obj.get_Appreciation_Evaluation(), Types.VARCHAR);
            statement.setObject(4, obj.get_ID_Evaluation(), Types.INTEGER);
            statement.executeUpdate(); //execute update for change in DB and executeQuery for select

        } catch (SQLException ex) {
            Logger.getLogger(DAOPersonne.class.getName()).log(Level.SEVERE, null, ex);
        }
        return true;
    }

    @Override
    public Evaluation find(int id_evaluation) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        
            Evaluation evaluation = new Evaluation();      
      
    try {
      ResultSet result = this.connect.createStatement(
        ResultSet.TYPE_SCROLL_INSENSITIVE,
        ResultSet.CONCUR_READ_ONLY).executeQuery("SELECT * FROM evaluation WHERE id_evaluation = " + id_evaluation);
      if(result.first())
        evaluation = new Evaluation(
          id_evaluation,
          result.getInt("id_detail_bulletin"),
          result.getFloat("note_evaluation"),
          result.getString("appreciation_evalution")
          
        );         
    } catch (SQLException e) {
      e.printStackTrace();
    }
    return evaluation;
    }
    
}
