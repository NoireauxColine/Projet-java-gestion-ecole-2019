/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import java.sql.*;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import modele.Detail_Bulletin;

/**
 *
 * @author coline & loic
 */
public class DAODetail_Bulletin extends DAO<Detail_Bulletin>{

    private ArrayList<Detail_Bulletin> listDetailBulletin;
    
    public DAODetail_Bulletin(){
        listDetailBulletin=new ArrayList<Detail_Bulletin>();
    }
    
    public DAODetail_Bulletin(Connection conn) {
        super(conn);
    }
    
    
    
    
    @Override
    public void setData(){
        
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/gestion_ecole", "root", "");
            Statement stmt = conn.createStatement();
            ResultSet result = stmt.executeQuery("SELECT * FROM detail_bulletin");
            while(result.next()){
                
                Detail_Bulletin matiere = new Detail_Bulletin(result.getInt("id_detail_bulletin"),result.getInt("id_bulletin"),result.getInt("id_enseignement"),result.getString("appreciation_detail"));
                listDetailBulletin.add(matiere);
            }
            stmt.close();
            conn.close();
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(DAOEcole.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public ArrayList<Detail_Bulletin> getList(){
        return listDetailBulletin;
    }
    
    

    @Override
    public boolean create(Detail_Bulletin obj) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        
         try {
            // prefer prepareStatement as statement to avoid SQL injection
            PreparedStatement statement = this.connect.prepareStatement(
                    "INSERT INTO detail_bulletin(id_detail_bulletin,id_bulletin,id_enseignement,appreciation_detail) VALUES(?,?,?,?)"
            );
            //insert param to change the ? into data
            statement.setObject(1, obj.get_ID_Detail(), Types.INTEGER);            
            statement.setObject(2, obj.get_ID_Bulletin(), Types.INTEGER);
            statement.setObject(3, obj.get_ID_Enseignement(), Types.INTEGER);
            statement.setObject(4, obj.get_Appreciation_Detail(), Types.VARCHAR);
            statement.executeUpdate(); //execute update for change in DB and executeQuery for select

        } catch (SQLException ex) {
            Logger.getLogger(DAOPersonne.class.getName()).log(Level.SEVERE, null, ex);
        }
        return true;
    }

    @Override
    public boolean delete(Detail_Bulletin obj) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        
         try {
            // prefer prepareStatement as statement to avoid SQL injection
            PreparedStatement statement = this.connect.prepareStatement(
                    "DELETE FROM detail_bulletin WHERE id_bulletin=?"
            );
            //insert param to change the ? into data
            statement.setObject(1, obj.get_ID_Detail(), Types.INTEGER);
            statement.executeUpdate(); //execute update for change in DB and executeQuery for select

        } catch (SQLException ex) {
            Logger.getLogger(DAOPersonne.class.getName()).log(Level.SEVERE, null, ex);
        }
        return true;
    }

    @Override
    public boolean update(Detail_Bulletin obj) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        
        try {
            // prefer prepareStatement as statement to avoid SQL injection
            PreparedStatement statement = this.connect.prepareStatement(
                    "UPDATE detail_bulletin SET id_bulletin=?,id_enseignement=?, appreciation_detail=?, WHERE id_bulletin=?"
            );
            //insert param to change the ? into data
            
            statement.setObject(1, obj.get_ID_Bulletin(), Types.INTEGER);
            statement.setObject(2, obj.get_ID_Enseignement(), Types.INTEGER);
            statement.setObject(3, obj.get_Appreciation_Detail(), Types.VARCHAR);
            statement.setObject(5, obj.get_ID_Detail(), Types.INTEGER);
            statement.executeUpdate(); //execute update for change in DB and executeQuery for select

        } catch (SQLException ex) {
            Logger.getLogger(DAOPersonne.class.getName()).log(Level.SEVERE, null, ex);
        }
        return true;
    }

    @Override
    public Detail_Bulletin find(int id_detail_bulletin) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        
            Detail_Bulletin detail_bulletin = new Detail_Bulletin();      
      
    try {
      ResultSet result = this.connect.createStatement(
        ResultSet.TYPE_SCROLL_INSENSITIVE,
        ResultSet.CONCUR_READ_ONLY).executeQuery("SELECT * FROM detail_bulletin WHERE id_bulletin = " + id_detail_bulletin);
      if(result.first())
        detail_bulletin = new Detail_Bulletin(
          id_detail_bulletin,          
          result.getInt("id_bulletin"),
          result.getInt("id_enseignement"),
          result.getString("appreciation_detail")
          );         
    } catch (SQLException e) {
      e.printStackTrace();
    }
    return detail_bulletin;
    }
    
}
