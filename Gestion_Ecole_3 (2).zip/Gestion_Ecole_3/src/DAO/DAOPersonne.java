/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import java.sql.Connection;
import java.sql.*;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import modele.*;

/**
 *
 * @author coline & loic
 */
public class DAOPersonne extends DAO<Personne>{

    private ArrayList<Personne> listPersonne;
    
    public DAOPersonne(){
        listPersonne=new ArrayList<Personne>();
    }
    
    public DAOPersonne(Connection conn) {
        super(conn);
    }
    
    
    
    @Override
    public void setData(){
        //Faire  DAOEcole e;
        //e.getData(); pour récupérer les données dans un ArrayList
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/gestion_ecole", "root", "");
            Statement stmt = conn.createStatement();
            ResultSet result = stmt.executeQuery("SELECT * FROM personne GROUP BY nom_personne"); //On fait un tri en sql pour éviter de le faire plus tard sur un ArrayList
            while(result.next()){
                Personne personne = new Personne(result.getInt("id_personne"),result.getString("nom_personne"),result.getString("prenom_personne"),result.getString("type_personne"), result.getString("Identifiant"), result.getString("Mdp"));
                listPersonne.add(personne);
            }
            stmt.close();
            conn.close();
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(DAOEcole.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public ArrayList<Personne> getList(){
        return listPersonne;
    }
    
    

    @Override
    public boolean create(Personne obj) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        
        try {
            // prefer prepareStatement as statement to avoid SQL injection
            PreparedStatement statement = this.connect.prepareStatement(
                    "INSERT INTO personne(id_personne,nom_personne,prenom_personne,type_personne,Identifiant,Mdp) VALUES(?,?,?,?,?,?)"
            );
            //insert param to change the ? into data
            statement.setObject(1, obj.get_ID_Personne(), Types.INTEGER);
            statement.setObject(2, obj.get_Nom_Personne(), Types.VARCHAR);
            statement.setObject(3, obj.get_Prenom_Personne(), Types.VARCHAR);
            statement.setObject(4, obj.get_Type_Personne(), Types.VARCHAR);
            statement.setObject(5, obj.getIdentifiant(), Types.VARCHAR);
            statement.setObject(6, obj.getMdp(), Types.VARCHAR);

            statement.executeUpdate(); //execute update for change in DB and executeQuery for select

        } catch (SQLException ex) {
            Logger.getLogger(DAOPersonne.class.getName()).log(Level.SEVERE, null, ex);
        }
        return true;
    }

    @Override
    public boolean delete(Personne obj) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        
        try {
            // prefer prepareStatement as statement to avoid SQL injection
            PreparedStatement statement = this.connect.prepareStatement(
                    "DELETE FROM personne WHERE id_personne=?"
            );
            //insert param to change the ? into data
            statement.setObject(1, obj.get_ID_Personne(), Types.INTEGER);
            statement.executeUpdate(); //execute update for change in DB and executeQuery for select

        } catch (SQLException ex) {
            Logger.getLogger(DAOPersonne.class.getName()).log(Level.SEVERE, null, ex);
        }
        return true;
    }

    @Override
    public boolean update(Personne obj) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        
        try {
            // prefer prepareStatement as statement to avoid SQL injection
            PreparedStatement statement = this.connect.prepareStatement(
                    "UPDATE personne SET nom_personne=?, prenom_personne=?, type_personne=?, Identifiant=?, Mdp=?, WHERE id_personne=?"
            );
            //insert param to change the ? into data
            statement.setObject(1, obj.get_Nom_Personne(), Types.VARCHAR);
            statement.setObject(2, obj.get_Prenom_Personne(), Types.VARCHAR);
            statement.setObject(3, obj.get_Type_Personne(), Types.VARCHAR);
            statement.setObject(4, obj.getIdentifiant(), Types.VARCHAR);
            statement.setObject(5, obj.getMdp(), Types.VARCHAR);
            statement.setObject(6, obj.get_ID_Personne(), Types.INTEGER);
            statement.executeUpdate(); //execute update for change in DB and executeQuery for select

        } catch (SQLException ex) {
            Logger.getLogger(DAOPersonne.class.getName()).log(Level.SEVERE, null, ex);
        }
        return true;
    }

    @Override
    public Personne find(int id_personne) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        
            Personne personne = new Personne();      
      
    try {
      ResultSet result = this.connect.createStatement(
        ResultSet.TYPE_SCROLL_INSENSITIVE,
        ResultSet.CONCUR_READ_ONLY).executeQuery("SELECT * FROM personne WHERE id_personne = " + id_personne);
      if(result.first())
        personne = new Personne(
          id_personne,
          result.getString("nom_personne"),
          result.getString("prenom_personne"),
          result.getString("type_personne"),
          result.getString("Identifiant"),
          result.getString("Mdp")
        );         
    } catch (SQLException e) {
      e.printStackTrace();
    }
    return personne;
    }
    
}
