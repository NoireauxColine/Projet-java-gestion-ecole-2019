/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modele;

/**
 *
 * @author coline
 */
public class Enseignement {
        
    //Attribut
    private int id_enseignement;
    private int id_classe;
    private int id_discipline;
    private int id_personne;
    
    //Constructeur par defaut
    public Enseignement(){
        id_enseignement=0;
        id_classe=0;
        id_discipline=0;
        id_personne=0;
    }
    
    //Constructeur surcharge
    public Enseignement(int id_enseignement, int id_classe, int id_discipline, int id_personne){
        this.id_enseignement=id_enseignement;
        this.id_classe=id_classe;
        this.id_discipline=id_discipline;
        this.id_personne=id_personne;
    }
    
    //getter et setter
    public int get_ID_Enseignement(){
        return id_enseignement;
    }
    
    public void set_ID_Enseignement(int id_enseignement){
        this.id_enseignement=id_enseignement;
    }

    public int get_ID_Classe() {
        return id_classe;
    }

    public void set_ID_Classe(int id_classe) {
        this.id_classe = id_classe;
    }

    public int get_ID_Discipline() {
        return id_discipline;
    }

    public void set_ID_Discipline(int id_discipline) {
        this.id_discipline = id_discipline;
    }

    public int get_ID_Personne() {
        return id_personne;
    }

    public void set_ID_Personne(int id_personne) {
        this.id_personne = id_personne;
    }
    
}
