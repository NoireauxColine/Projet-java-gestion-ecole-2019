/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vue;

import java.awt.FlowLayout;
import java.awt.Label;
import java.awt.TextField;
import javax.swing.BoxLayout;
import static javax.swing.BoxLayout.Y_AXIS;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import modele.Bulletin;

/**
 *
 * @author mathi
 */
   
public class Interface extends JPanel {
    private Bulletin b;
    
    public Interface(Bulletin b)
    {
        this.b=b;
        this.setLayout(new BoxLayout(this,Y_AXIS));
    
        JLabel t1=new JLabel("le trimestre numero est "+b.getTrimestre().get_Numero_Trimestre()
                + "année : "+b.getTrimestre().getAnneeScolaire());
        this.add(t1);
        
        JLabel evaluation=new JLabel("Evaluations");
        this.add(evaluation);
        
       
        
    }

}
