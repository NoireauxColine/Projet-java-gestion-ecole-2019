/**
 * Package modele contient declaration et implementation des classes correspondant aux tables de la bdd
 * Classe, Bulletin, Personne...
 * 
 */
package modele;


  
    