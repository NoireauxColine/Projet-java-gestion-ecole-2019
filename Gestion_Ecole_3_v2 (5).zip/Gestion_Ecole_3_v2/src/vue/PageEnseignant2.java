/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vue;

import controleur.DAOEcole;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.table.DefaultTableModel;
import modele.BDD;
import modele.Bulletin;
import modele.Detail_Bulletin;
import modele.Evaluation;
import modele.Inscription;
import modele.Personne;

/**
 *
 * @author LOL & coline
 */
public class PageEnseignant2 extends javax.swing.JFrame {
    

     // Variables declaration - do not modify                     
    private javax.swing.JLabel AdresseEcole;
    private javax.swing.JLabel Bulletin;
    private javax.swing.JLabel NomEcole;
    private javax.swing.JLabel NomPrenomEleve;
    private javax.swing.JLabel Titre_page;
    private javax.swing.JButton deconnexion;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JComboBox jComboBox1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTable2;
    private int id_personne;
    // End of variables declaration 
    /**
     * Creates new form PageEnseignant
     */
    public PageEnseignant2(Personne P) throws SQLException {
        
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jPanel1 = new javax.swing.JPanel();
        Titre_page = new javax.swing.JLabel();
        NomPrenomEleve = new javax.swing.JLabel();
        NomEcole = new javax.swing.JLabel();
        AdresseEcole = new javax.swing.JLabel();
        Bulletin = new javax.swing.JLabel();
        deconnexion = new javax.swing.JButton();
        jComboBox1 = new javax.swing.JComboBox();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        
        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        
        jTable2.setAutoCreateRowSorter(true);
        
        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                
            },
            new String [] {
                "Elève", "Coeff", "Moyenne Elève", "Moyenne Classe", "Appréciation"
            }
        ){
            
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.Integer.class, java.lang.Float.class, java.lang.Float.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };
            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        
        //Fixe la largeur de la taille des colonnes dans le tableau
        jTable2.getTableHeader().setReorderingAllowed(false);
        jScrollPane3.setViewportView(jTable2);
        if (jTable2.getColumnModel().getColumnCount() > 0) {
            jTable2.getColumnModel().getColumn(0).setMinWidth(100);
            jTable2.getColumnModel().getColumn(0).setMaxWidth(100);
            jTable2.getColumnModel().getColumn(1).setMinWidth(100);
            jTable2.getColumnModel().getColumn(1).setMaxWidth(100);
            jTable2.getColumnModel().getColumn(2).setMinWidth(150);
            jTable2.getColumnModel().getColumn(2).setMaxWidth(150);
            jTable2.getColumnModel().getColumn(3).setMinWidth(150);
            jTable2.getColumnModel().getColumn(3).setMaxWidth(150);
            jTable2.getColumnModel().getColumn(4).setMinWidth(150);
            jTable2.getColumnModel().getColumn(4).setMaxWidth(150);
        }

        

        Titre_page.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        Titre_page.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Titre_page.setText("Page Enseignant");

        NomPrenomEleve.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        NomPrenomEleve.setText("Nom :      Prenom");
        
        BDD bdd = new BDD();
        id_personne = P.get_ID_Personne();
        String sql = "SELECT * FROM inscription JOIN classe ON inscription.id_classe=classe.id_classe "
                    + "WHERE classe.id_annee_scolaire=(SELECT MAX(id_annee_scolaire) FROM annee_scolaire) AND inscription.id_personne="+P.get_ID_Personne()+"";
        
        String nomEcole = "";
        String adresseEcole = "";
        try{
            Class.forName("com.mysql.jdbc.Driver");
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/gestion_ecole", "root", "");
            Statement stmt = conn.createStatement();
            ResultSet result = stmt.executeQuery(sql); 
            while(result.next()){
                for(Inscription I : bdd.getListInscription()){
                    //id_inscription de l'élève le plus récent
                    if (I.get_ID_Inscription()==result.getInt("id_inscription")){
                        //niveau = I.getClasse().getNiveau().get_Nom_Niveau()+" "+I.getClasse().get_Nom_Classe();
                        nomEcole = I.getClasse().getEcole().get_Nom_Ecole();
                        adresseEcole = I.getClasse().getEcole().get_Adresse_Ecole();
                    }
                }
            }
            stmt.close();
            conn.close();
        }catch (ClassNotFoundException ex) {
            Logger.getLogger(DAOEcole.class.getName()).log(Level.SEVERE, null, ex);
        }

        NomEcole.setText("NomEcole");

        AdresseEcole.setText("AdresseEcole");

        Bulletin.setFont(new java.awt.Font("Tahoma", 1, 10)); // NOI18N
        Bulletin.setForeground(new java.awt.Color(0, 0, 204));
        Bulletin.setText("Bulletin");
        Bulletin.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                BulletinMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                BulletinMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                BulletinMouseExited(evt);
            }
        });

        deconnexion.setText("Deconnexion");
        deconnexion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deconnexionActionPerformed(evt);
            }
        });

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "TS1", "TS2" }));

        jButton1.setText("Supprimer un DS");

        jButton2.setText("Modifier une note");

        jButton3.setText("Modifier un Coeff");

        jButton4.setText("Ajouter une note");

        jButton5.setText("Supprimer une note");

        jButton6.setText("Ajouter un DS");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(40, 40, 40)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(NomPrenomEleve, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(NomEcole, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(AdresseEcole, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(Bulletin, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(Titre_page, javax.swing.GroupLayout.PREFERRED_SIZE, 236, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(462, 462, 462)
                        .addComponent(deconnexion, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(2147482747, 2147482747, 2147482747))))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(36, 36, 36)
                .addComponent(jButton1)
                .addGap(18, 18, 18)
                .addComponent(jButton2)
                .addGap(18, 18, 18)
                .addComponent(jButton3)
                .addGap(18, 18, 18)
                .addComponent(jButton4)
                .addGap(18, 18, 18)
                .addComponent(jButton5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jButton6)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Titre_page, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(deconnexion, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(NomPrenomEleve, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(NomEcole, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(AdresseEcole, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton1)
                    .addComponent(jButton2)
                    .addComponent(jButton3)
                    .addComponent(jButton4)
                    .addComponent(jButton5)
                    .addComponent(jButton6))
                .addGap(56, 56, 56)
                .addComponent(Bulletin, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        Titre_page.getAccessibleContext().setAccessibleDescription("");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addGap(38, 38, 38)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 651, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(32078, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 259, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(116, Short.MAX_VALUE))
        );

        setSize(new java.awt.Dimension(914, 727));
        setLocationRelativeTo(null);      
                
        
        
    }

    public PageEnseignant2() {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    
    
    private void BulletinMouseClicked(java.awt.event.MouseEvent evt) {
        
        //affiche le bulletin spécifié dans la tableau
        //le texte du JLabel Bulletin est de la forme : "Bulletin trimestre 1, Année Scolaire 2018-2019"
        String str = Bulletin.getText().toString();
        System.out.println(str);
        str = str.substring(9,str.length()-1-8);//on extrait une partie de la chaine de caractère pour enlever <html><u>
        System.out.println(str);
        String numTrimestre = str.substring(19,20);
        String annee = str.substring(37,41);
        int numeroTrimestre = Integer.valueOf(numTrimestre).intValue();
        int an = Integer.valueOf(annee).intValue();
        //System.out.println(numeroTrimestre);
        //System.out.println(an);
        
        
        BDD bdd = new BDD();
        ArrayList<Evaluation> list = bdd.getListEvaluation();
        int id_inscription = 0;
        
        for (Inscription I : bdd.getListInscription()){
            int id_personne = 0;
            if (I.getClasse().get_ID_Annee_Scolaire()==an && I.get_ID_Personne()==id_personne){
                id_inscription=I.get_ID_Inscription();
            }
        }
        
        //nettoyage du tableau
        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
            },
            new String [] {
                "Matière", "Coefficient", "Note/Moyenne", "Moyenne classe", "Appréciation"
            }
        ){
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.Integer.class, java.lang.Float.class, java.lang.Float.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };
            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        
        jTable2.getTableHeader().setReorderingAllowed(false);
        jScrollPane3.setViewportView(jTable2);
        if (jTable2.getColumnModel().getColumnCount() > 0) {
            jTable2.getColumnModel().getColumn(0).setMinWidth(200);//Matière
            jTable2.getColumnModel().getColumn(0).setMaxWidth(220);//Matière
            jTable2.getColumnModel().getColumn(1).setMinWidth(70);//Coefficient
            jTable2.getColumnModel().getColumn(1).setMaxWidth(70);//Coefficient
            jTable2.getColumnModel().getColumn(2).setMinWidth(100);//Note, moyenne
            jTable2.getColumnModel().getColumn(2).setMaxWidth(100);//Note, moyenne
            jTable2.getColumnModel().getColumn(3).setMinWidth(100);//moyenne classe
            jTable2.getColumnModel().getColumn(3).setMaxWidth(100);//moyenne classe
        }
        
        //Remplissage du tableau
        DefaultTableModel model = (DefaultTableModel) jTable2.getModel();
        //for(int i=0;i<5;i++) model.removeRow(i);
        Object[] row = new Object[5];
        
        for (Bulletin B : bdd.getListBulletin()){
            if (B.getTrimestre().get_ID_Annee_Scolaire()==an 
                && B.getTrimestre().get_Numero_Trimestre()==numeroTrimestre 
                && B.get_ID_Bulletin()==id_inscription){
                for(Detail_Bulletin db : bdd.getListDetailBulletin()){
                    if (db.get_ID_Bulletin()==B.get_ID_Bulletin()){
                        row[0] = db.getEnseignement().getDiscipline().get_Nom_Discipline()+": "+db.getEnseignement().getPersonne().getCivilite()+" "+db.getEnseignement().getPersonne().get_Nom_Personne();
                        row[1] = "";//Coefficient
                        row[2] = db.getMoyenneEleve();//moyenne et le matière et notes de DS
                        row[3] = db.getMoyenneClasse();//Moyenne de la matière dans la classe
                        row[4] = db.get_Appreciation_Detail(); //Appréciation
                        model.addRow(row);
			for(Evaluation E : bdd.getListEvaluation()){
				if(E.get_ID_Detail_Bulletin()==db.get_ID_Detail()){
					row[0] = E.getDS().get_Nom_DS();//Nom du devoir
                        		row[1] = E.getCoeff();//Coefficient
                        		row[2] = E.get_Note_Evaluation();//moyenne et le matière et notes de DS
                        		row[3] = E.getMoyenneEvaluation();//Moyenne de la matière dans la classe
                        		row[4] = E.get_Appreciation_Evaluation(); //Appréciation
                        		model.addRow(row);
				}
			}
                    }
                }
                row[0] = "Moyenne générale";//Nom du devoir
                row[1] = "";//Coefficient
                row[2] = B.getMoyenneGeneraleEleve();//moyenne et le matière et notes de DS
                row[3] = B.getMoyenneGeneraleClasse();//Moyenne de la matière dans la classe
                row[4] = B.get_Appreciation_Bulletin(); //Appréciation
                model.addRow(row);
                
                
            }
        }
        
        
    }

    public void BulletinMouseEntered(java.awt.event.MouseEvent evt) {                                      
        // TODO add your handling code here:
        // Cette méthode est appelée quand la souris entre dans la zone du composant écouté 
        String str = Bulletin.getText().toString();
        Bulletin.setText("<html><u>"+str+"<html><u>");
    }                                     

    public void BulletinMouseExited(java.awt.event.MouseEvent evt) {                                     
        //Enlève le surlignement lorsque la souris entre dans le JLabel Bulletin
        String str = Bulletin.getText().toString().substring(9,17);
        Bulletin.setText(str);
        
    }                                    

    
    
    private void deconnexionActionPerformed(java.awt.event.ActionEvent evt) {                                            
        //L'elève se déconnecte
        this.setVisible(false);//cache la page élève
        
        PageConnexion pg = new PageConnexion();
        pg.setVisible(true);
        pg.setTitle("Connexion");
        pg.setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        pg.setSize(500,430);
        pg.setResizable(false); //empêche le redimensionnement
        pg.setLocationRelativeTo(null); //fenêtre positionné au centre de l'écran de l'ordinateur
    }

    /**
     * @param args the command line arguments
     */
   

                     
}
